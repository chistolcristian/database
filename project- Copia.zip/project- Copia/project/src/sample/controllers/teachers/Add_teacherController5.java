/**
 * Sample Skeleton for 'add_teacher.fxml' Controller Class
 */

package sample.controllers.teachers;


import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import sample.controllers.TeachersController;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;


public class Add_teacherController5 {
    @FXML // ResourceBundle that was given to the FXMLLoader
    private ResourceBundle resources;

    @FXML // URL location of the FXML file that was given to the FXMLLoader
    private URL location;

    @FXML
    public TextField materiaflash;

    @FXML
    public TextField nomeflash;

    @FXML
    public TextField cognomeflash;

    @FXML
    public TextField cittàflash;

    @FXML
    public TextField sessoflash;

    @FXML
    public TextField etàflash;


    @FXML
        // This method is called by the FXMLLoader when initialization is complete
    void initialize() {

    }

    @FXML

    public void dettagli() throws IOException {
             if (TeachersController.materia1 == null) {
                 materiaflash.setText("Telecomunicazioni");
             } else {
                 materiaflash.setText(TeachersController.materia1);
            }

            if (TeachersController.nome1 == null) {
                nomeflash.setText("Priamo");
            } else {
                nomeflash.setText(TeachersController.nome1);
            }

            if (TeachersController.cognome1 == null) {
                cognomeflash.setText("Verdasio");
            } else {
                cognomeflash.setText(TeachersController.cognome1);
            }
            if (TeachersController.città1 == null) {
                cittàflash.setText("Brescia(BS)");
            } else {
                cittàflash.setText(TeachersController.città1);
            }
            if (TeachersController.sesso1 == null) {
                sessoflash.setText("M");
            } else {
                sessoflash.setText(TeachersController.sesso1);
            }
            if (TeachersController.età1 == null) {
                etàflash.setText("51");
            } else {
                etàflash.setText(TeachersController.età1);
            }


            materiaflash.setEditable(false);
            nomeflash.setEditable(false);
            cognomeflash.setEditable(false);
            cittàflash.setEditable(false);
            sessoflash.setEditable(false);
            etàflash.setEditable(false);

        }


        public void edit() throws IOException {

            materiaflash.setEditable(true);
            nomeflash.setEditable(true);
            cognomeflash.setEditable(true);
            cittàflash.setEditable(true);
            sessoflash.setEditable(true);
            etàflash.setEditable(true);


        }

        public void confirm() throws IOException {

            TeachersController.materia1 = materiaflash.getText();
            TeachersController.nome1 = nomeflash.getText();
            TeachersController.cognome1 = cognomeflash.getText();
            TeachersController.città1 = cittàflash.getText();
            TeachersController.sesso1 = sessoflash.getText();
            TeachersController.età1 = etàflash.getText();
            materiaflash.setEditable(false);
            nomeflash.setEditable(false);
            cognomeflash.setEditable(false);
            cittàflash.setEditable(false);
            sessoflash.setEditable(false);
            etàflash.setEditable(false);

        }

        public void delete() throws IOException{
            materiaflash.clear();
            nomeflash.clear();
            cognomeflash.clear();
            cittàflash.clear();
            sessoflash.clear();
            etàflash.clear();

        }


    }
