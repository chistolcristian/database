/**
 * Sample Skeleton for 'add_teacher.fxml' Controller Class
 */

package sample.controllers.teachers;


import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import sample.controllers.TeachersController;


public class Add_teacherController1 {
    @FXML // ResourceBundle that was given to the FXMLLoader
    private ResourceBundle resources;

    @FXML // URL location of the FXML file that was given to the FXMLLoader
    private URL location;

    @FXML
    public TextField materiaflash;

    @FXML
    public TextField nomeflash;

    @FXML
    public TextField cognomeflash;

    @FXML
    public TextField cittàflash;

    @FXML
    public TextField sessoflash;

    @FXML
    public TextField etàflash;


    @FXML
        // This method is called by the FXMLLoader when initialization is complete
    void initialize() {

    }

    @FXML

    public void dettagli() throws IOException {
             if (TeachersController.materia== null) {
                 materiaflash.setText("Italiano");
             } else {
                 materiaflash.setText(TeachersController.materia);
            }

            if (TeachersController.nome == null) {
                nomeflash.setText("Bertoldo");
            } else {
                nomeflash.setText(TeachersController.nome);
            }

            if (TeachersController.cognome == null) {
                cognomeflash.setText("Rettani");
            } else {
                cognomeflash.setText(TeachersController.cognome);
            }
            if (TeachersController.città == null) {
                cittàflash.setText("Borgosatollo(BS)");
            } else {
                cittàflash.setText(TeachersController.città);
            }
            if (TeachersController.sesso == null) {
                sessoflash.setText("M");
            } else {
                sessoflash.setText(TeachersController.sesso);
            }
            if (TeachersController.età == null) {
                etàflash.setText("49");
            } else {
                etàflash.setText(TeachersController.età);
            }


            materiaflash.setEditable(false);
            nomeflash.setEditable(false);
            cognomeflash.setEditable(false);
            cittàflash.setEditable(false);
            sessoflash.setEditable(false);
            etàflash.setEditable(false);

        }


        public void edit () throws IOException {
            materiaflash.setEditable(true);
            nomeflash.setEditable(true);
            cognomeflash.setEditable(true);
            cittàflash.setEditable(true);
            sessoflash.setEditable(true);
            etàflash.setEditable(true);


        }

        public void confirm () throws IOException {
            TeachersController.materia = materiaflash.getText();
            TeachersController.nome = nomeflash.getText();
            TeachersController.cognome = cognomeflash.getText();
            TeachersController.città = cittàflash.getText();
            TeachersController.sesso = sessoflash.getText();
            TeachersController.età = etàflash.getText();
            materiaflash.setEditable(false);
            nomeflash.setEditable(false);
            cognomeflash.setEditable(false);
            cittàflash.setEditable(false);
            sessoflash.setEditable(false);
            etàflash.setEditable(false);

        }
        public void delete() throws IOException{
        materiaflash.clear();
        nomeflash.clear();
        cognomeflash.clear();
        cittàflash.clear();
        sessoflash.clear();
        etàflash.clear();

    }

    }
