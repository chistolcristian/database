/**
 * Sample Skeleton for 'add_teacher.fxml' Controller Class
 */

package sample.controllers.teachers;


import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import sample.controllers.TeachersController;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;


public class Add_teacherController3 {
    @FXML // ResourceBundle that was given to the FXMLLoader
    private ResourceBundle resources;

    @FXML // URL location of the FXML file that was given to the FXMLLoader
    private URL location;

    @FXML
    public TextField materiaflash;

    @FXML
    public TextField nomeflash;

    @FXML
    public TextField cognomeflash;

    @FXML
    public TextField cittàflash;

    @FXML
    public TextField sessoflash;

    @FXML
    public TextField etàflash;


    @FXML
        // This method is called by the FXMLLoader when initialization is complete
    void initialize() {

    }

    @FXML

    public void dettagli() throws IOException {
             if (TeachersController.materia2 == null) {
                 materiaflash.setText("Inglese");
             } else {
                 materiaflash.setText(TeachersController.materia2);
            }

            if (TeachersController.nome2 == null) {
                nomeflash.setText("Gilberta");
            } else {
                nomeflash.setText(TeachersController.nome2);
            }

            if (TeachersController.cognome2 == null) {
                cognomeflash.setText("Palatano");
            } else {
                cognomeflash.setText(TeachersController.cognome2);
            }
            if (TeachersController.città2 == null) {
                cittàflash.setText("Iseo(BS)");
            } else {
                cittàflash.setText(TeachersController.città2);
            }
            if (TeachersController.sesso2 == null) {
                sessoflash.setText("F");
            } else {
                sessoflash.setText(TeachersController.sesso2);
            }
            if (TeachersController.età2 == null) {
                etàflash.setText("34");
            } else {
                etàflash.setText(TeachersController.età2);
            }


            materiaflash.setEditable(false);
            nomeflash.setEditable(false);
            cognomeflash.setEditable(false);
            cittàflash.setEditable(false);
            sessoflash.setEditable(false);
            etàflash.setEditable(false);

        }


        public void edit() throws IOException {

            materiaflash.setEditable(true);
            nomeflash.setEditable(true);
            cognomeflash.setEditable(true);
            cittàflash.setEditable(true);
            sessoflash.setEditable(true);
            etàflash.setEditable(true);


        }

        public void confirm() throws IOException {

            TeachersController.materia2 = materiaflash.getText();
            TeachersController.nome2 = nomeflash.getText();
            TeachersController.cognome2 = cognomeflash.getText();
            TeachersController.città2 = cittàflash.getText();
            TeachersController.sesso2 = sessoflash.getText();
            TeachersController.età2 = etàflash.getText();
            materiaflash.setEditable(false);
            nomeflash.setEditable(false);
            cognomeflash.setEditable(false);
            cittàflash.setEditable(false);
            sessoflash.setEditable(false);
            etàflash.setEditable(false);

        }

        public void delete() throws IOException{
            materiaflash.clear();
            nomeflash.clear();
            cognomeflash.clear();
            cittàflash.clear();
            sessoflash.clear();
            etàflash.clear();

        }


    }
