/**
 * Sample Skeleton for 'add_teacher.fxml' Controller Class
 */

package sample.controllers.students;


import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import sample.controllers.StudentsController;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;


public class Add_studentController4 {
    @FXML // ResourceBundle that was given to the FXMLLoader
    private ResourceBundle resources;

    @FXML // URL location of the FXML file that was given to the FXMLLoader
    private URL location;

    @FXML
    public TextField nomeflash;

    @FXML
    public TextField cognomeflash;

    @FXML
    public TextField cittàflash;

    @FXML
    public TextField sessoflash;

    @FXML
    public TextField etàflash;


    @FXML
        // This method is called by the FXMLLoader when initialization is complete
    void initialize() {

    }

    @FXML

    public void dettagli() throws IOException {

        if (StudentsController.nome3 == null) {
            nomeflash.setText("Fiorella");
        } else {
            nomeflash.setText(StudentsController.nome3);
        }

        if (StudentsController.cognome3 == null) {
            cognomeflash.setText("Rieni");
        } else {
            cognomeflash.setText(StudentsController.cognome3);
        }
        if (StudentsController.città3 == null) {
            cittàflash.setText("CastelMella(BS)");
        } else {
            cittàflash.setText(StudentsController.città3);
        }
        if (StudentsController.sesso3 == null) {
            sessoflash.setText("F");
        } else {
            sessoflash.setText(StudentsController.sesso3);
        }
        if (StudentsController.età3 == null) {
            etàflash.setText("20");
        } else {
            etàflash.setText(StudentsController.età3);
        }

        nomeflash.setEditable(false);
        cognomeflash.setEditable(false);
        cittàflash.setEditable(false);
        sessoflash.setEditable(false);
        etàflash.setEditable(false);

    }


    public void edit () throws IOException {
        nomeflash.setEditable(true);
        cognomeflash.setEditable(true);
        cittàflash.setEditable(true);
        sessoflash.setEditable(true);
        etàflash.setEditable(true);


    }

    public void confirm () throws IOException {
        StudentsController.nome3 = nomeflash.getText();
        StudentsController.cognome3 = cognomeflash.getText();
        StudentsController.città3 = cittàflash.getText();
        StudentsController.sesso3 = sessoflash.getText();
        StudentsController.età3 = etàflash.getText();
        nomeflash.setEditable(false);
        cognomeflash.setEditable(false);
        cittàflash.setEditable(false);
        sessoflash.setEditable(false);
        etàflash.setEditable(false);

    }
    public void delete() throws IOException{
        nomeflash.clear();
        cognomeflash.clear();
        cittàflash.clear();
        sessoflash.clear();
        etàflash.clear();

    }

    }
