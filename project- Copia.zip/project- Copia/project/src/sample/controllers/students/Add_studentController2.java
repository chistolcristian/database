/**
 * Sample Skeleton for 'add_teacher.fxml' Controller Class
 */

package sample.controllers.students;


import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import sample.controllers.StudentsController;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;


public class Add_studentController2 {
    @FXML // ResourceBundle that was given to the FXMLLoader
    private ResourceBundle resources;

    @FXML // URL location of the FXML file that was given to the FXMLLoader
    private URL location;

    @FXML
    public TextField nomeflash;

    @FXML
    public TextField cognomeflash;

    @FXML
    public TextField cittàflash;

    @FXML
    public TextField sessoflash;

    @FXML
    public TextField etàflash;


    @FXML
        // This method is called by the FXMLLoader when initialization is complete
    void initialize() {

    }

    @FXML

    public void dettagli() throws IOException {
        if (StudentsController.nome1 == null) {
            nomeflash.setText("Loredana");
        } else {
            nomeflash.setText(StudentsController.nome1);
        }

        if (StudentsController.cognome1 == null) {
            cognomeflash.setText("Maietto");
        } else {
            cognomeflash.setText(StudentsController.cognome1);
        }
        if (StudentsController.città1 == null) {
            cittàflash.setText("Brescia(BS)");
        } else {
            cittàflash.setText(StudentsController.città1);
        }
        if (StudentsController.sesso1 == null) {
            sessoflash.setText("F");
        } else {
            sessoflash.setText(StudentsController.sesso1);
        }
        if (StudentsController.età1 == null) {
            etàflash.setText("18");
        } else {
            etàflash.setText(StudentsController.età1);
        }


        nomeflash.setEditable(false);
        cognomeflash.setEditable(false);
        cittàflash.setEditable(false);
        sessoflash.setEditable(false);
        etàflash.setEditable(false);

    }


    public void edit () throws IOException {
        nomeflash.setEditable(true);
        cognomeflash.setEditable(true);
        cittàflash.setEditable(true);
        sessoflash.setEditable(true);
        etàflash.setEditable(true);


    }

    public void confirm () throws IOException {
        StudentsController.nome1 = nomeflash.getText();
        StudentsController.cognome1 = cognomeflash.getText();
        StudentsController.città1 = cittàflash.getText();
        StudentsController.sesso1 = sessoflash.getText();
        StudentsController.età1 = etàflash.getText();
        nomeflash.setEditable(false);
        cognomeflash.setEditable(false);
        cittàflash.setEditable(false);
        sessoflash.setEditable(false);
        etàflash.setEditable(false);

    }
    public void delete() throws IOException{
        nomeflash.clear();
        cognomeflash.clear();
        cittàflash.clear();
        sessoflash.clear();
        etàflash.clear();

    }

    }
