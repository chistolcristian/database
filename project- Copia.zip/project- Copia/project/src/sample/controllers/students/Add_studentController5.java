/**
 * Sample Skeleton for 'add_teacher.fxml' Controller Class
 */

package sample.controllers.students;


import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import sample.controllers.StudentsController;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;


public class Add_studentController5 {

    @FXML // ResourceBundle that was given to the FXMLLoader
    private ResourceBundle resources;

    @FXML // URL location of the FXML file that was given to the FXMLLoader
    private URL location;

    @FXML
    public TextField nomeflash;

    @FXML
    public TextField cognomeflash;

    @FXML
    public TextField cittàflash;

    @FXML
    public TextField sessoflash;

    @FXML
    public TextField etàflash;


    @FXML
        // This method is called by the FXMLLoader when initialization is complete
    void initialize() {

    }

    @FXML

    public void dettagli() throws IOException {

        if (StudentsController.nome4 == null) {
            nomeflash.setText("Gianni");
        } else {
            nomeflash.setText(StudentsController.nome4);
        }

        if (StudentsController.cognome4 == null) {
            cognomeflash.setText("Biscola");
        } else {
            cognomeflash.setText(StudentsController.cognome4);
        }
        if (StudentsController.città4 == null) {
            cittàflash.setText("Rezzato(BS)");
        } else {
            cittàflash.setText(StudentsController.città4);
        }
        if (StudentsController.sesso4 == null) {
            sessoflash.setText("M");
        } else {
            sessoflash.setText(StudentsController.sesso4);
        }
        if (StudentsController.età4 == null) {
            etàflash.setText("19");
        } else {
            etàflash.setText(StudentsController.età4);
        }


        nomeflash.setEditable(false);
        cognomeflash.setEditable(false);
        cittàflash.setEditable(false);
        sessoflash.setEditable(false);
        etàflash.setEditable(false);

    }


    public void edit () throws IOException {
        nomeflash.setEditable(true);
        cognomeflash.setEditable(true);
        cittàflash.setEditable(true);
        sessoflash.setEditable(true);
        etàflash.setEditable(true);


    }

    public void confirm () throws IOException {
        StudentsController.nome4 = nomeflash.getText();
        StudentsController.cognome4 = cognomeflash.getText();
        StudentsController.città4 = cittàflash.getText();
        StudentsController.sesso4 = sessoflash.getText();
        StudentsController.età4 = etàflash.getText();
        nomeflash.setEditable(false);
        cognomeflash.setEditable(false);
        cittàflash.setEditable(false);
        sessoflash.setEditable(false);
        etàflash.setEditable(false);

    }
    public void delete() throws IOException{
        nomeflash.clear();
        cognomeflash.clear();
        cittàflash.clear();
        sessoflash.clear();
        etàflash.clear();

    }


    }
