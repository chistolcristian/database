/**
 * Sample Skeleton for 'parents.fxml' Controller Class
 */

package sample.controllers;


import java.awt.*;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class ParentsController {

    public static String nome,cognome,città,sesso,età,contatto,lavoro;
    public static String nome1,cognome1,città1,sesso1,età1,contatto1,lavoro1;
    public static String nome2,cognome2,città2,sesso2,età2,contatto2,lavoro2;
    public static String nome3,cognome3,città3,sesso3,età3,contatto3,lavoro3;
    public static String nome4,cognome4,città4,sesso4,età4,contatto4,lavoro4;



    @FXML // ResourceBundle that was given to the FXMLLoader
    private ResourceBundle resources;

    @FXML // URL location of the FXML file that was given to the FXMLLoader
    private URL location;



    @FXML
    void add_parent1(MouseEvent event) {
        try {

            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/sample/views/parents/add_parent1.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setTitle("GENITORE1");
            stage.setScene(new Scene(root1));
            stage.show();
            stage.setResizable(false);

        } catch (Exception e) {
            System.out.println("can't load new window");

        }

    }

    @FXML
    void add_parent2(MouseEvent event) {
        try {

            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/sample/views/parents/add_parent2.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setTitle("GENITORE2");
            stage.setScene(new Scene(root1));
            stage.show();
            stage.setResizable(false);

        } catch (Exception e) {
            System.out.println("can't load new window");

        }

    }

    @FXML
    void add_parent3(MouseEvent event) {
        try {

            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/sample/views/parents/add_parent3.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setTitle("GENITORE3");
            stage.setScene(new Scene(root1));
            stage.show();
            stage.setResizable(false);

        } catch (Exception e) {
            System.out.println("can't load new window");

        }

    }

    @FXML
    void add_parent4(MouseEvent event) {
        try {

            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/sample/views/parents/add_parent4.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setTitle("GENITORE4");
            stage.setScene(new Scene(root1));
            stage.show();
            stage.setResizable(false);

        } catch (Exception e) {
            System.out.println("can't load new window");

        }

    }

    @FXML
    void add_parent5(MouseEvent event) {
        try {

            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/sample/views/parents/add_parent5.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setTitle("GENITORE5");
            stage.setScene(new Scene(root1));
            stage.show();
            stage.setResizable(false);

        } catch (Exception e) {
            System.out.println("can't load new window");

        }

    }

}

