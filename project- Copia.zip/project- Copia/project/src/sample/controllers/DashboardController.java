package sample.controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.awt.*;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;

public class DashboardController {
    @FXML
    private Button btnPage;

    @FXML
    private Button btnLogout;

    @FXML
    private Button btnIndirizzi;

    public void logout() throws IOException {
        btnLogout.getScene().getWindow().hide();
        AnchorPane root = (AnchorPane) FXMLLoader.load(getClass().getResource("/sample/views/login.fxml"));
        Stage primaryStage = new Stage();
        primaryStage.setTitle("Login");
        primaryStage.setScene(new Scene(root, 330, 200));
        primaryStage.show();
        primaryStage.setResizable(false);
    }

    public void indirizzi() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/sample/views/materie.fxml"));
        Parent root1 = (Parent) fxmlLoader.load();
        Stage stage = new Stage();
        stage.setTitle("INDIRIZZI");
        stage.setScene(new Scene(root1));
        stage.show();
        stage.setResizable(false);


    }

    public void page() throws IOException, URISyntaxException {

        Desktop.getDesktop().browse(new URL("https://github.com/chistolcristian/database").toURI());

    }

}



