/**
 * Sample Skeleton for 'teachers.fxml' Controller Class
 */

package sample.controllers;

import java.awt.*;
import java.lang.String;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.scene.control.TextField;
import sample.controllers.teachers.Add_teacherController1;


public class TeachersController {
    public static String nome,materia,cognome,città,sesso,età ;
    public static String nome1,materia1,cognome1,città1,sesso1,età1;
    public static String nome2,materia2,cognome2,città2,sesso2,età2;
    public static String nome3,materia3,cognome3,città3,sesso3,età3;
    public static String nome4,materia4,cognome4,città4,sesso4,età4;


    @FXML // ResourceBundle that was given to the FXMLLoader
    private ResourceBundle resources;

    @FXML // URL location of the FXML file that was given to the FXMLLoader
    private URL location;

    @FXML
    void add_teacher1(MouseEvent event) {
        try {

            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/sample/views/teachers/add_teacher1.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setTitle("DOCENTE1");
            stage.setScene(new Scene(root1));
            stage.show();
            stage.setResizable(false);

        } catch (Exception e) {
            System.out.println("can't load new window");

        }

    }

    @FXML
    void add_teacher2(MouseEvent event) {
        try {

            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/sample/views/teachers/add_teacher2.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setTitle("DOCENTE2");
            stage.setScene(new Scene(root1));
            stage.show();
            stage.setResizable(false);

        } catch (Exception e) {
            System.out.println("can't load new window");

        }

    }

    @FXML
    void add_teacher3(MouseEvent event) {
        try {

            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/sample/views/teachers/add_teacher3.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setTitle("DOCENTE3");
            stage.setScene(new Scene(root1));
            stage.show();
            stage.setResizable(false);

        } catch (Exception e) {
            System.out.println("can't load new window");

        }

    }

    @FXML
    void add_teacher4(MouseEvent event) {
        try {

            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/sample/views/teachers/add_teacher4.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setTitle("DOCENTE4");
            stage.setScene(new Scene(root1));
            stage.show();
            stage.setResizable(false);

        } catch (Exception e) {
            System.out.println("can't load new window");

        }

    }

    @FXML
    void add_teacher5(MouseEvent event) {
        try {

            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/sample/views/teachers/add_teacher5.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setTitle("DOCENTE5");
            stage.setScene(new Scene(root1));
            stage.show();
            stage.setResizable(false);

        } catch (Exception e) {
            System.out.println("can't load new window");

        }

    }

}

