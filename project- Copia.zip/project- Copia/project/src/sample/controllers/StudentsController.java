/**
 * Sample Skeleton for 'teachers.fxml' Controller Class
 */

package sample.controllers;

import java.awt.*;
import java.lang.String;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.scene.control.TextField;



public class StudentsController {
    public static String nome,genitore,cognome,città,sesso,età ;
    public static String nome1,genitore1,cognome1,città1,sesso1,età1;
    public static String nome2,genitore2,cognome2,città2,sesso2,età2;
    public static String nome3,genitore3,cognome3,città3,sesso3,età3;
    public static String nome4,genitore4,cognome4,città4,sesso4,età4;


    @FXML // ResourceBundle that was given to the FXMLLoader
    private ResourceBundle resources;

    @FXML // URL location of the FXML file that was given to the FXMLLoader
    private URL location;

    @FXML
    void add_student1(MouseEvent event) {
        try {

            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/sample/views/students/add_student1.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setTitle("STUDENTE1");
            stage.setScene(new Scene(root1));
            stage.show();
            stage.setResizable(false);

        } catch (Exception e) {
            System.out.println("can't load new window");

        }

    }

    @FXML
    void add_student2(MouseEvent event) {
        try {

            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/sample/views/students/add_student2.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setTitle("STUDENTE2");
            stage.setScene(new Scene(root1));
            stage.show();
            stage.setResizable(false);

        } catch (Exception e) {
            System.out.println("can't load new window");

        }

    }

    @FXML
    void add_student3(MouseEvent event) {
        try {

            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/sample/views/students/add_student3.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setTitle("STUDENTE3");
            stage.setScene(new Scene(root1));
            stage.show();
            stage.setResizable(false);

        } catch (Exception e) {
            System.out.println("can't load new window");

        }

    }

    @FXML
    void add_student4(MouseEvent event) {
        try {

            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/sample/views/students/add_student4.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setTitle("STUDENTE4");
            stage.setScene(new Scene(root1));
            stage.show();
            stage.setResizable(false);

        } catch (Exception e) {
            System.out.println("can't load new window");

        }

    }

    @FXML
    void add_student5(MouseEvent event) {
        try {

            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/sample/views/students/add_student5.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setTitle("STUDENTE5");
            stage.setScene(new Scene(root1));
            stage.show();
            stage.setResizable(false);

        } catch (Exception e) {
            System.out.println("can't load new window");

        }

    }

}