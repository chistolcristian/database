/**
 * Sample Skeleton for 'app.fxml' Controller Class
 */

package sample.controllers;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import java.io.IOException;

import javafx.stage.Stage;
import sample.helpers.DynamicViews;

public class AppController {

    @FXML // ResourceBundle that was given to the FXMLLoader
    private ResourceBundle resources;

    @FXML // URL location of the FXML file that was given to the FXMLLoader
    private URL location;

    @FXML // fx:id="border_pane"
    private BorderPane border_pane; // Value injected by FXMLLoader

    @FXML
    void show_dashboard(MouseEvent event) throws IOException {
        DynamicViews.loadBorderCenter(border_pane,"dashboard");
    }

    @FXML
    void show_parents(MouseEvent event) throws IOException {
        DynamicViews.loadBorderCenter(border_pane,"parents");
    }


    @FXML
    void show_students(MouseEvent event) throws IOException {
        DynamicViews.loadBorderCenter(border_pane,"students");
    }

    @FXML
    void show_subjects(MouseEvent event) throws IOException {
        DynamicViews.loadBorderCenter(border_pane,"materie");
    }

    @FXML
    void show_teachers(MouseEvent event) throws IOException {
        DynamicViews.loadBorderCenter(border_pane,"teachers");
    }


    @FXML // This method is called by the FXMLLoader when initialization is complete
    void initialize() {
        assert border_pane != null : "fx:id=\"border_pane\" was not injected: check your FXML file 'app.fxml'.";

    }


    }

