package sample.controllers;


import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {

    @FXML
    private TextField txtUsername;

    @FXML
    private TextField txtPassword;

    @FXML
    private Button btnLogin;

    @FXML
    private Button btnCancel;

    public void login() throws IOException {
        String Username = txtUsername.getText();
        String Password = txtPassword.getText();

        Alert message = new Alert(Alert.AlertType.ERROR);
        if (Username.equals("admin") && Password.equals("1234") ) {
            btnLogin.getScene().getWindow().hide();
            Parent root = FXMLLoader.load(getClass().getResource("/sample/views/app.fxml"));
            Stage primaryStage = new Stage();
            primaryStage.setTitle("App");
            primaryStage.setScene(new Scene(root, 550, 550));
            primaryStage.show();
            primaryStage.setResizable(false);


        } else {
            message.setContentText("Username o Password Sbagliata");
            message.setTitle("Unsuccessful login");
            message.show();

        }
        txtPassword.setText("");
        txtUsername.setText("");
    }

    public void cancelLogin(){
        Platform.exit();

    }


}