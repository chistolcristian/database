/**
 * Sample Skeleton for 'add_teacher.fxml' Controller Class
 */

package sample.controllers.parents;


import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import sample.controllers.ParentsController;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;


public class Add_parentController4 {
    @FXML // ResourceBundle that was given to the FXMLLoader
    private ResourceBundle resources;

    @FXML // URL location of the FXML file that was given to the FXMLLoader
    private URL location;

    @FXML
    private TextField nomeflash;

    @FXML
    private TextField cognomeflash;

    @FXML
    private TextField cittàflash;

    @FXML
    private TextField sessoflash;

    @FXML
    private TextField etàflash;

    @FXML
    private TextField lavoroflash;


    @FXML
    private TextField contattoflash;



    @FXML
        // This method is called by the FXMLLoader when initialization is complete
    void initialize() {

    }

    @FXML

    public void dettagli() throws IOException {
        if (ParentsController.contatto3== null) {
            contattoflash.setText("00393707503158");
        } else {
            contattoflash.setText(ParentsController.contatto3);
        }

        if (ParentsController.nome3 == null) {
            nomeflash.setText("Annamaria");
        } else {
            nomeflash.setText(ParentsController.nome3);
        }

        if (ParentsController.cognome3 == null) {
            cognomeflash.setText("Rieni");
        } else {
            cognomeflash.setText(ParentsController.cognome3);
        }
        if (ParentsController.città3 == null) {
            cittàflash.setText("CastelMella(BS)");
        } else {
            cittàflash.setText(ParentsController.città3);
        }
        if (ParentsController.sesso3 == null) {
            sessoflash.setText("F");
        } else {
            sessoflash.setText(ParentsController.sesso3);
        }
        if (ParentsController.età3 == null) {
            etàflash.setText("40");
        } else {
            etàflash.setText(ParentsController.età3);
        }
        if (ParentsController.lavoro3 == null) {
            lavoroflash.setText("Antropologo");
        } else {
            lavoroflash.setText(ParentsController.lavoro3);
        }


        contattoflash.setEditable(false);
        nomeflash.setEditable(false);
        cognomeflash.setEditable(false);
        cittàflash.setEditable(false);
        sessoflash.setEditable(false);
        etàflash.setEditable(false);
        lavoroflash.setEditable(false);

    }


    public void edit () throws IOException {
        contattoflash.setEditable(true);
        nomeflash.setEditable(true);
        cognomeflash.setEditable(true);
        cittàflash.setEditable(true);
        sessoflash.setEditable(true);
        etàflash.setEditable(true);
        lavoroflash.setEditable(true);



    }

    public void confirm () throws IOException {
        ParentsController.contatto3 = contattoflash.getText();
        ParentsController.nome3 = nomeflash.getText();
        ParentsController.cognome3 = cognomeflash.getText();
        ParentsController.città3 = cittàflash.getText();
        ParentsController.sesso3 = sessoflash.getText();
        ParentsController.età3 = etàflash.getText();
        ParentsController.lavoro3 = lavoroflash.getText();
        contattoflash.setEditable(false);
        nomeflash.setEditable(false);
        cognomeflash.setEditable(false);
        cittàflash.setEditable(false);
        sessoflash.setEditable(false);
        etàflash.setEditable(false);
        lavoroflash.setEditable(false);



    }
    public void delete() throws IOException{
        contattoflash.clear();
        nomeflash.clear();
        cognomeflash.clear();
        cittàflash.clear();
        sessoflash.clear();
        etàflash.clear();
        lavoroflash.clear();

    }


    }
