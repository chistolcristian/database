/**
 * Sample Skeleton for 'add_teacher.fxml' Controller Class
 */

package sample.controllers.parents;


import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import sample.controllers.ParentsController;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;


public class Add_parentController2 {
    @FXML // ResourceBundle that was given to the FXMLLoader
    private ResourceBundle resources;

    @FXML // URL location of the FXML file that was given to the FXMLLoader
    private URL location;

    @FXML
    private TextField nomeflash;

    @FXML
    private TextField cognomeflash;

    @FXML
    private TextField cittàflash;

    @FXML
    private TextField sessoflash;

    @FXML
    private TextField etàflash;

    @FXML
    private TextField lavoroflash;


    @FXML
    private TextField contattoflash;


    @FXML
        // This method is called by the FXMLLoader when initialization is complete
    void initialize() {

    }

    @FXML

    public void dettagli() throws IOException {
        if (ParentsController.contatto1 == null) {
            contattoflash.setText("00393738204750");
        } else {
            contattoflash.setText(ParentsController.contatto1);
        }

        if (ParentsController.nome1 == null) {
            nomeflash.setText("Desideria");
        } else {
            nomeflash.setText(ParentsController.nome1);
        }

        if (ParentsController.cognome1 == null) {
            cognomeflash.setText("Maietto");
        } else {
            cognomeflash.setText(ParentsController.cognome1);
        }
        if (ParentsController.città1 == null) {
            cittàflash.setText("Brescia(BS)");
        } else {
            cittàflash.setText(ParentsController.città1);
        }
        if (ParentsController.sesso1 == null) {
            sessoflash.setText("F");
        } else {
            sessoflash.setText(ParentsController.sesso1);
        }
        if (ParentsController.età1 == null) {
            etàflash.setText("31");
        } else {
            etàflash.setText(ParentsController.età1);
        }
        if (ParentsController.lavoro1 == null) {
            lavoroflash.setText("Conduttore Televisivo");
        } else {
            lavoroflash.setText(ParentsController.lavoro1);
        }


        contattoflash.setEditable(false);
        nomeflash.setEditable(false);
        cognomeflash.setEditable(false);
        cittàflash.setEditable(false);
        sessoflash.setEditable(false);
        etàflash.setEditable(false);
        lavoroflash.setEditable(false);

    }


    public void edit() throws IOException {
        contattoflash.setEditable(true);
        nomeflash.setEditable(true);
        cognomeflash.setEditable(true);
        cittàflash.setEditable(true);
        sessoflash.setEditable(true);
        etàflash.setEditable(true);
        lavoroflash.setEditable(true);


    }

    public void confirm() throws IOException {
        ParentsController.contatto1 = contattoflash.getText();
        ParentsController.nome1 = nomeflash.getText();
        ParentsController.cognome1 = cognomeflash.getText();
        ParentsController.città1 = cittàflash.getText();
        ParentsController.sesso1 = sessoflash.getText();
        ParentsController.età1 = etàflash.getText();
        ParentsController.lavoro1 = lavoroflash.getText();
        contattoflash.setEditable(false);
        nomeflash.setEditable(false);
        cognomeflash.setEditable(false);
        cittàflash.setEditable(false);
        sessoflash.setEditable(false);
        etàflash.setEditable(false);
        lavoroflash.setEditable(false);


    }

    public void delete() throws IOException {
        contattoflash.clear();
        nomeflash.clear();
        cognomeflash.clear();
        cittàflash.clear();
        sessoflash.clear();
        etàflash.clear();
        lavoroflash.clear();

    }

}