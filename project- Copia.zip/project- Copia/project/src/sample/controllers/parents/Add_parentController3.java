/**
 * Sample Skeleton for 'add_teacher.fxml' Controller Class
 */

package sample.controllers.parents;


import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import sample.controllers.ParentsController;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;


public class Add_parentController3 {
    @FXML // ResourceBundle that was given to the FXMLLoader
    private ResourceBundle resources;

    @FXML // URL location of the FXML file that was given to the FXMLLoader
    private URL location;

    @FXML
    private TextField nomeflash;

    @FXML
    private TextField cognomeflash;

    @FXML
    private TextField cittàflash;

    @FXML
    private TextField sessoflash;

    @FXML
    private TextField etàflash;

    @FXML
    private TextField lavoroflash;


    @FXML
    private TextField contattoflash;



    @FXML
        // This method is called by the FXMLLoader when initialization is complete
    void initialize() {

    }

    @FXML

    public void dettagli() throws IOException {
        if (ParentsController.contatto2== null) {
            contattoflash.setText("00393791436082 ");
        } else {
            contattoflash.setText(ParentsController.contatto2);
        }

        if (ParentsController.nome2 == null) {
            nomeflash.setText("Fedro");
        } else {
            nomeflash.setText(ParentsController.nome2);
        }

        if (ParentsController.cognome2 == null) {
            cognomeflash.setText("Inclinati");
        } else {
            cognomeflash.setText(ParentsController.cognome2);
        }
        if (ParentsController.città2 == null) {
            cittàflash.setText("Gussago(BS)");
        } else {
            cittàflash.setText(ParentsController.città2);
        }
        if (ParentsController.sesso2 == null) {
            sessoflash.setText("M");
        } else {
            sessoflash.setText(ParentsController.sesso2);
        }
        if (ParentsController.età2 == null) {
            etàflash.setText("49");
        } else {
            etàflash.setText(ParentsController.età2);
        }
        if (ParentsController.lavoro2 == null) {
            lavoroflash.setText("Storico Dell'arte");
        } else {
            lavoroflash.setText(ParentsController.lavoro2);
        }


        contattoflash.setEditable(false);
        nomeflash.setEditable(false);
        cognomeflash.setEditable(false);
        cittàflash.setEditable(false);
        sessoflash.setEditable(false);
        etàflash.setEditable(false);
        lavoroflash.setEditable(false);

    }


    public void edit () throws IOException {
        contattoflash.setEditable(true);
        nomeflash.setEditable(true);
        cognomeflash.setEditable(true);
        cittàflash.setEditable(true);
        sessoflash.setEditable(true);
        etàflash.setEditable(true);
        lavoroflash.setEditable(true);



    }

    public void confirm () throws IOException {
        ParentsController.contatto2 = contattoflash.getText();
        ParentsController.nome2 = nomeflash.getText();
        ParentsController.cognome2 = cognomeflash.getText();
        ParentsController.città2 = cittàflash.getText();
        ParentsController.sesso2 = sessoflash.getText();
        ParentsController.età2 = etàflash.getText();
        ParentsController.lavoro2 = lavoroflash.getText();
        contattoflash.setEditable(false);
        nomeflash.setEditable(false);
        cognomeflash.setEditable(false);
        cittàflash.setEditable(false);
        sessoflash.setEditable(false);
        etàflash.setEditable(false);
        lavoroflash.setEditable(false);



    }
    public void delete() throws IOException{
        contattoflash.clear();
        nomeflash.clear();
        cognomeflash.clear();
        cittàflash.clear();
        sessoflash.clear();
        etàflash.clear();
        lavoroflash.clear();

    }


    }
