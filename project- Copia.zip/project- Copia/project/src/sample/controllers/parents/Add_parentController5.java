/**
 * Sample Skeleton for 'add_teacher.fxml' Controller Class
 */

package sample.controllers.parents;


import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import sample.controllers.ParentsController;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;


public class Add_parentController5 {
    @FXML // ResourceBundle that was given to the FXMLLoader
    private ResourceBundle resources;

    @FXML // URL location of the FXML file that was given to the FXMLLoader
    private URL location;

    @FXML
    private TextField nomeflash;

    @FXML
    private TextField cognomeflash;

    @FXML
    private TextField cittàflash;

    @FXML
    private TextField sessoflash;

    @FXML
    private TextField etàflash;

    @FXML
    private TextField lavoroflash;


    @FXML
    private TextField contattoflash;



    @FXML
        // This method is called by the FXMLLoader when initialization is complete
    void initialize() {

    }

    @FXML

    public void dettagli() throws IOException {
        if (ParentsController.contatto4 == null) {
            contattoflash.setText("00393137436082 ");
        } else {
            contattoflash.setText(ParentsController.contatto4);
        }

        if (ParentsController.nome4 == null) {
            nomeflash.setText("Eligio");
        } else {
            nomeflash.setText(ParentsController.nome4);
        }

        if (ParentsController.cognome4 == null) {
            cognomeflash.setText("Biscola");
        } else {
            cognomeflash.setText(ParentsController.cognome4);
        }
        if (ParentsController.città4 == null) {
            cittàflash.setText("Rezzato(BS)");
        } else {
            cittàflash.setText(ParentsController.città4);
        }
        if (ParentsController.sesso4 == null) {
            sessoflash.setText("M");
        } else {
            sessoflash.setText(ParentsController.sesso4);
        }
        if (ParentsController.età4 == null) {
            etàflash.setText("56");
        } else {
            etàflash.setText(ParentsController.età4);
        }
        if (ParentsController.lavoro4 == null) {
            lavoroflash.setText("Disegnatore Grafico");
        } else {
            lavoroflash.setText(ParentsController.lavoro4);
        }


        contattoflash.setEditable(false);
        nomeflash.setEditable(false);
        cognomeflash.setEditable(false);
        cittàflash.setEditable(false);
        sessoflash.setEditable(false);
        etàflash.setEditable(false);
        lavoroflash.setEditable(false);

    }


    public void edit () throws IOException {
        contattoflash.setEditable(true);
        nomeflash.setEditable(true);
        cognomeflash.setEditable(true);
        cittàflash.setEditable(true);
        sessoflash.setEditable(true);
        etàflash.setEditable(true);
        lavoroflash.setEditable(true);



    }

    public void confirm () throws IOException {
        ParentsController.contatto4 = contattoflash.getText();
        ParentsController.nome4 = nomeflash.getText();
        ParentsController.cognome4 = cognomeflash.getText();
        ParentsController.città4 = cittàflash.getText();
        ParentsController.sesso4 = sessoflash.getText();
        ParentsController.età4 = etàflash.getText();
        ParentsController.lavoro4 = lavoroflash.getText();
        contattoflash.setEditable(false);
        nomeflash.setEditable(false);
        cognomeflash.setEditable(false);
        cittàflash.setEditable(false);
        sessoflash.setEditable(false);
        etàflash.setEditable(false);
        lavoroflash.setEditable(false);



    }
    public void delete() throws IOException{
        contattoflash.clear();
        nomeflash.clear();
        cognomeflash.clear();
        cittàflash.clear();
        sessoflash.clear();
        etàflash.clear();
        lavoroflash.clear();

    }


    }
