package sample.helpers;

import javafx.scene.Parent;
import java.io.IOException;
import javafx.scene.layout.BorderPane;
import static javafx.fxml.FXMLLoader.*;

public class DynamicViews {

    private DynamicViews(){
    }
    public static void loadBorderCenter(BorderPane borderPane, String resource) throws IOException {
        Parent dashboard = load(new DynamicViews().getClass().getResource("/sample/views/"+ resource +".fxml"));
        borderPane.setCenter(dashboard);
    }
}
